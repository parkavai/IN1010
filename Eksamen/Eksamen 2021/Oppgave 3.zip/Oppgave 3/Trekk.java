// Oppgave 1 c.)

import java.util.Random;

public class Trekk {

    static int trekkInt(int min, int max){
        int tilfeldig = (int)(Math.random()*max);
        return tilfeldig;
    }
    
}
