// Oppgave 2 c.)

public class Simulator {

    private int globaltid;
    private PrioKoe<Aktivitet> prioritetskoe = new PrioKoe<>();
    private Aktivitet[] listeAvAktiviteter;

    Simulator(Aktivitet[] listeAvAktiviteter){
        globaltid = 0;
        this.listeAvAktiviteter= listeAvAktiviteter;
        for(int i = 0; i < listeAvAktiviteter.length; i++){
            prioritetskoe.settInn(listeAvAktiviteter[i]);
        }
    }

    public void simuler(int t){
        while(globaltid < t){
            Aktivitet lavest = prioritetskoe.hentUt();
            globaltid = lavest.tid;
            lavest.handling();
            lavest.tid += globaltid;
            prioritetskoe.settInn(lavest);
        }
    }


    
}
