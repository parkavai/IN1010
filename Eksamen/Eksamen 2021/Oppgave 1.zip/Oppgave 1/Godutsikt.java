// Oppgave 1 c.)

interface Godutsikt {

    boolean harGodUtsikt();
    
}
