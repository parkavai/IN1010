public class TestSimulator {

    public static void main(String[] args) {
        
        final int ANTTURGAAER = 10;
        Skog skogen = new Skog(100, 100);
        Aktivitet[] listeAvTurgaaer = new Aktivitet[10];
        for(int i = 0; i <= ANTTURGAAER; i++){
            int hastighet = Trekk.trekkInt(20, 200);
            Turgaaer turgaaer = new Turgaaer(hastighet, skogen.hentTilfeldigKryss());
            listeAvTurgaaer[i] = turgaaer;
        }
        Simulator simulasjon = new Simulator(listeAvTurgaaer);
        for(int i = 0; i < listeAvTurgaaer.length; i++){
            simulasjon.simuler(Trekk.trekkInt(30, 480));
        }
    }
    
}
