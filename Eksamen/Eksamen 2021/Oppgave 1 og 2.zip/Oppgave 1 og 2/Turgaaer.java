// Oppgave 2 d.)

public class Turgaaer extends Aktivitet{
    private int hastighet;
    private Kryss sted;
    private int tiden = 0;
    Turgaaer(int hastighet, Kryss sted){
        super();
        this.sted = sted;
    }

    @Override 
    public void handling(){
        int gaatid = 0;
        if(!(sted.erIsolert())){
            Sti stien = sted.hentTilfeldigSti();
            Sti nySti = stien.finnAndreEnde().hentTilfeldigSti();
            gaatid = nySti.beregnGaaTid(hastighet);
        }
        tiden = gaatid;
    }

    
}
