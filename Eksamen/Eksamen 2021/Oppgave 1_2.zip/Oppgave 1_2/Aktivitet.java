// Oppgave 2 a.)

abstract class Aktivitet implements Comparable<Aktivitet>{

    Aktivitet hoyere;
    Aktivitet lavere;
    int tid = 0;
    
    Aktivitet(){
        hoyere = null; 
        lavere = null;
    }

    abstract void handling();

    @Override 
    // Skiller mellom hvilke som er lavere og hvilke som er hoye
    public int compareTo(Aktivitet annen){
        if(this.hoyere.tid < annen.hoyere.tid){
            return -1;
        }
        else {
            return 1;
        }
    }
    
}